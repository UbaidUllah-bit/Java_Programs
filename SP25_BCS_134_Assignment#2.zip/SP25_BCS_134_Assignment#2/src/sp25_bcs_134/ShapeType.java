package sp25_bcs_134;

public enum ShapeType{

	   RECTANGLE, TRAPEZOID, L_SHAPE;


}