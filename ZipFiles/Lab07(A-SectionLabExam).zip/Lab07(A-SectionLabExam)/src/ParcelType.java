public enum ParcelType{

	Regular, Fragile;

}