public enum ParcelStatus{

	IN_STORAGE, OUT_OF_STORAGE;


}