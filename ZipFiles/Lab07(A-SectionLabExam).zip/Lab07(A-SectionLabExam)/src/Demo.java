public class Demo{

	public static void main(String[] args){


		/*Parcel P1 = new Parcel(111, ParcelType.Regular);
		System.out.println(P1);

		FragileParcel F1 = new FragileParcel(222);
		System.out.println(F1);*/

		//Slot s1 = new Slot(2,10);

		//System.out.println(s1);

		//s1.addParcel(111, ParcelType.Regular);
		//System.out.println(s1.getSlotById("R2-S10"));

		
		/*System.out.println(s1.getId());
		/*System.out.println(s1.getParcel());
		System.out.println(s1.getSlotType());		
		System.out.println(s1);*/



		//System.out.println(r1);

		Depot d1 = new Depot("LahoreDepot", 4);
		
		System.out.println(d1);
		

		System.out.println(d1);
		





	}


}