public class Rack{

	Slot[][] slots;
	int[] rowLength;
	
	private String rackId;

	int row;
	int column;

	Rack(int Id, int[] rowLength){

		this.rackId = String.format("LR-%d", Id);

		slots = new Slot[rowLength.length][];

		for(int i = 0; i < slots.length; i++){

			slots[i] = new Slot[rowLength[i]];

		}

		for(int i = 0; i < slots.length; i++){

			for(int j = 0; j < slots[i].length; j++){

				slots[i][j] = new Slot(i + 1, j + 1);

			}


		}


	}

	public String getRackId(){

		return rackId;

	}

	public void addParcel(int row, int column, int Id, ParcelType type){

		if(slots[row][column].toString().equals("[--]")){

			slots[row][column].addParcel(Id, type);
			System.out.println(" Parcel " + slots[row][column].getId() + " added successfully! ");
		}

		else{

			System.out.println("Slot is already in use!" );

		}

	

	}

	public void removeParcel(String Id){

		for(int i = 0; i < slots.length; i++){

			for(int j = 0; j < slots[i].length; j++){

				if(slots[i][j].getId().equals(Id)){

					slots[i][j].removeParcel();
					System.out.println(" Parcel " + slots[row][column].getId() + " removed successfully! ");
					return;

				}

			}

		}

		System.out.println("Parcel Id: " + Id + " not found or is already empty.");

	}

	public void findFirstAvailable(){

		for(int i = 0; i < slots.length; i++){

			for(int j = 0; j < slots[i].length; j++){

				if(slots[i][j].equals("[--]")){

					System.out.println("Available Slot found at" + slots[i][j].getId());
					return;

				}


			}

		}

	}

	public Parcel[] getParcelsByType(ParcelType type){

		int count = 0;
		for(int i = 0; i < slots.length; i++){

			for(int j = 0 ; j < slots[i].length; j++){

				if(slots[i][j].getSlotType() == type){

					count++;

				}


			}

		}

		Parcel availableParcel[] = new Parcel[count];
		int index = 0;
		for(int i = 0; i < slots.length; i++){

			for(int j = 0 ; j < slots[i].length; j++){

				if(slots[i][j].getSlotType() == type){

					availableParcel[index] = slots[i][j].getParcel();
					index ++;

				}


			}

		}

		return availableParcel;


	}

	@Override
	public String toString(){

		StringBuilder str = new StringBuilder();

		str.append(rackId + "\n");
		for(int i = 0; i < slots.length; i++){

			str.append("R" +(i+1)+": ");
			for(int j = 0; j < slots[i].length; j++){

				str.append(slots[i][j] + " ");

			}
			
			str.append("\n");

			}

		return str.toString();

		}

}