public class Depot{

	String name;
	int rackLength;
	Rack[] racks;

	Depot(String name, int rackLength){

		this.name = name;
		this.rackLength = rackLength;

		racks = new Rack[rackLength];

		
		for(int i = 0; i < racks.length; i++){

				racks[i] = new Rack(i+1, new int[] {i+1, i+2, i+3});

			}

		}
	

	public void displayLayout(){

		for(int i = 0; i < racks.length; i++){

			System.out.println(name);
			System.out.println(racks[i] + "\n");


		}

	}


	public void findFirstAvailable(){


		for(int i = 0; i < racks.length; i++){

			if(racks[i].getRackId() != null){

				racks[i].findFirstAvailable();
				return;

			}



		}

		System.out.println("Cannot find an empty slot!");

	}
	


	@Override
	public String toString(){

		StringBuilder str = new StringBuilder();
		str.append(name + "\n");
		for(int i = 0; i < racks.length; i++){

			str.append(racks[i] + "\n");

			}

		return str.toString();

	}


}	